function showInviteMenu(groupName)
  local inviteMenu = getElementData(localPlayer, "inviteMenu")
  if isElement(inviteMenu) then
    destroyElement(inviteMenu)
  end
  triggerServerEvent("onPlayerRequestInvite", localPlayer, groupName)
end
addEvent("onShowInviteMenu", true)
addEventHandler("onShowInviteMenu", root, showInviteMenu)

function receiveInvite(groupName)
  local inviteMenu = createInviteMenu(groupName)
  setElementData(localPlayer, "inviteMenu", inviteMenu, false)
end
addEvent("onReceiveInvite", true)
addEventHandler("onReceiveInvite", root, receiveInvite)