function onPlayerKey(player, key, state)
  if key == "F9" and state then
    local account = getPlayerAccount(player)
    if isObjectInACLGroup("user."..getAccountName(account), aclGetGroup("Lideres")) then
      local hasPermission = false
      local groupNames = {"PRF", "PCESP", "PMESP", "FT", "ROTA", "DETRAN", "SAMU"}
      for i, groupName in ipairs(groupNames) do
        if isObjectInACLGroup("user."..getAccountName(account), aclGetGroup(groupName)) then
          hasPermission = true
          local inviteMenu = createInviteMenu(groupName)
          setElementData(player, "inviteMenu", inviteMenu, false)
          break
        end
      end
      if not hasPermission then
        outputChatBox("Você não tem permissão para convidar jogadores para um grupo.", player, 255, 0, 0)
      end
    else
      outputChatBox("Você não é um líder de grupo.", player, 255, 0, 0)
    end
  end
end
addEventHandler("onPlayerKey", root, onPlayerKey)

function createInviteMenu(groupName)
  local inviteMenu = createMenu("", "Convite para o grupo "..groupName)
  local logo = guiCreateStaticImage(0.2, 0.1, 0.6, 0.4, "assets/images/logo_"..groupName..".png", true, inviteMenu)

  local acceptButton = guiCreateButton(0.1, 0.6, 0.35, 0.2, "Aceitar", true, inviteMenu)
  addEventHandler("onClientGUIClick", acceptButton, function()
    triggerServerEvent("onPlayerAcceptInvite", localPlayer, groupName)
    destroyElement(inviteMenu)
  end, false)
  local declineButton = guiCreateButton(0.55, 0.6, 0.35, 0.2, "Recusar", true, inviteMenu)
  addEventHandler("onClientGUIClick", declineButton, function()
    destroyElement(inviteMenu)
  end, false)
  return inviteMenu
end

addEvent("onPlayerAcceptInvite", true)
addEventHandler("onPlayerAcceptInvite", root, function(groupName)
  local account = getPlayerAccount(localPlayer)
  if not isObjectInACLGroup("user."..getAccountName(account), aclGetGroup(groupName)) then
    aclGroupAddObject(aclGetGroup(groupName), "user."..getAccountName(account))
    outputChatBox("Você foi adicionado ao grupo "..groupName.." com sucesso.", localPlayer, 0, 255, 0)
  else
    outputChatBox("Você já faz parte do grupo "..groupName..".", localPlayer, 255, 0, 0)
  end
end)