function onPlayerAcceptInvite(groupName)
  local player = client
  if not isElement(player) or getElementType(player) ~= "player" then
    return
  end
  local account = getPlayerAccount(player)
  local group = aclGetGroup(groupName)
  if not isObjectInACLGroup("user."..getAccountName(account), group) then
    aclGroupAddObject(group, "user."..getAccountName(account))
    outputChatBox("Você foi adicionado ao grupo "..groupName..".", player, 0, 255, 0)
  else
    outputChatBox("Você já é membro do grupo "..groupName..".", player, 255, 0, 0)
  end
end
addEvent("onPlayerAcceptInvite", true)
addEventHandler("onPlayerAcceptInvite", root, onPlayerAcceptInvite)